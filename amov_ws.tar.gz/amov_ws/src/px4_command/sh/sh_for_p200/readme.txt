修改下列文件中的/home/nvidia/amov_ws/src/px4_command/config/Parameter_for_control.yaml ‘flag_use_laser_or_vicon’参数，选择uav位置来源。
